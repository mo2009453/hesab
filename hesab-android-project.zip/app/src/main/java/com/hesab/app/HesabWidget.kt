package com.hesab.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class HesabWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { draw(context, manager, it) }
    }

    companion object {
        fun draw(ctx: Context, mgr: AppWidgetManager, id: Int) {
            val p = ctx.getSharedPreferences("w", Context.MODE_PRIVATE)
            val v = RemoteViews(ctx.packageName, R.layout.widget)
            v.setTextViewText(R.id.w_month, (p.getString("month", "0") ?: "0") + " جنيه")
            v.setTextViewText(R.id.w_today, "النهارده: " + (p.getString("today", "0") ?: "0"))
            v.setTextViewText(R.id.w_debt, "متأخرات عند العملاء: " + (p.getString("debt", "0") ?: "0"))
            val pi = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            v.setOnClickPendingIntent(R.id.w_root, pi)
            mgr.updateAppWidget(id, v)
        }

        fun refresh(ctx: Context) {
            val m = AppWidgetManager.getInstance(ctx)
            m.getAppWidgetIds(ComponentName(ctx, HesabWidget::class.java)).forEach { draw(ctx, m, it) }
        }
    }
}
