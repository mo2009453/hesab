package com.hesab.app

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private var pendingTag = ""
    private var camUri: Uri? = null

    private val pick = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        chooser?.onReceiveValue(if (uri != null) arrayOf(uri) else null)
        chooser = null
    }
    private val pickImg = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) Thread { storePhoto(uri) }.start()
    }
    private val takePic = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = camUri
        if (ok && u != null) Thread { storePhoto(u) }.start()
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun photosDir(): File = File(filesDir, "photos").apply { mkdirs() }

    private fun storePhoto(uri: Uri) {
        val id = "p" + System.currentTimeMillis()
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
            var s = 1
            while (bounds.outWidth / s > 1280 || bounds.outHeight / s > 1280) s *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = s }
            var bmp = contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, opts) }!!
            val o = contentResolver.openInputStream(uri)!!.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            }
            val deg = when (o) { ExifInterface.ORIENTATION_ROTATE_90 -> 90f; ExifInterface.ORIENTATION_ROTATE_180 -> 180f; ExifInterface.ORIENTATION_ROTATE_270 -> 270f; else -> 0f }
            if (deg != 0f) {
                val m = Matrix(); m.postRotate(deg)
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            FileOutputStream(File(photosDir(), "$id.jpg")).use { bmp.compress(Bitmap.CompressFormat.JPEG, 80, it) }
            val tag = pendingTag.replace("'", "")
            web.post { web.evaluateJavascript("window.onPhoto&&window.onPhoto('$tag','$id')", null) }
        } catch (e: Exception) {
            web.post { web.evaluateJavascript("window.onPhotoErr&&window.onPhotoErr()", null) }
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun summary(month: String, today: String, debt: String, visits: String) {
            getSharedPreferences("w", MODE_PRIVATE).edit()
                .putString("month", month).putString("today", today).putString("debt", debt).putString("visits", visits).apply()
            HesabWidget.refresh(applicationContext)
        }

        @JavascriptInterface
        fun saveBackup(name: String, json: String) {
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "application/json")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                ?: throw IllegalStateException("insert failed")
            contentResolver.openOutputStream(uri)!!.use { it.write(json.toByteArray(Charsets.UTF_8)) }
        }

        @JavascriptInterface
        fun photo(tag: String, source: String) {
            pendingTag = tag
            runOnUiThread {
                if (source == "camera") {
                    val dir = File(cacheDir, "cam").apply { mkdirs() }
                    val f = File(dir, "c" + System.currentTimeMillis() + ".jpg")
                    val u = FileProvider.getUriForFile(this@MainActivity, "$packageName.fp", f)
                    camUri = u
                    takePic.launch(u)
                } else {
                    pickImg.launch("image/*")
                }
            }
        }

        @JavascriptInterface
        fun getPhoto(id: String): String {
            val f = File(photosDir(), id.filter { it.isLetterOrDigit() } + ".jpg")
            if (!f.exists()) return ""
            return "data:image/jpeg;base64," + Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
        }

        @JavascriptInterface
        fun delPhoto(id: String) {
            File(photosDir(), id.filter { it.isLetterOrDigit() } + ".jpg").delete()
        }

        @JavascriptInterface
        fun setReminders(json: String) {
            Rem.apply(applicationContext, json)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "HesabNative")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                if (url.scheme == "file") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, url)) } catch (_: Exception) {}
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                w: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams
            ): Boolean {
                chooser?.onReceiveValue(null)
                chooser = cb
                val t = params.acceptTypes.firstOrNull { it.startsWith("image/") }
                pick.launch(t ?: "*/*")
                return true
            }
        }
        web.loadUrl("file:///android_asset/index.html")
    }
}
