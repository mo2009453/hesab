package com.hesab.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import org.json.JSONArray

object Snd {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("snd", Context.MODE_PRIVATE)
    private fun ver(ctx: Context) = prefs(ctx).getInt("ver", 1)

    fun uri(ctx: Context): Uri =
        prefs(ctx).getString("uri", null)?.let { Uri.parse(it) } ?: Settings.System.DEFAULT_NOTIFICATION_URI

    fun channelId(ctx: Context): String {
        val id = "appts" + ver(ctx)
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(id) == null) {
            val ch = NotificationChannel(id, "المواعيد", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(
                uri(ctx),
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            ch.enableVibration(true)
            nm.createNotificationChannel(ch)
        }
        return id
    }

    fun set(ctx: Context, u: Uri?) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val v = ver(ctx)
        nm.deleteNotificationChannel("appts$v")
        prefs(ctx).edit().putString("uri", u?.toString()).putInt("ver", v + 1).apply()
        channelId(ctx)
    }

    fun name(ctx: Context): String =
        try { RingtoneManager.getRingtone(ctx, uri(ctx)).getTitle(ctx) } catch (e: Exception) { "الافتراضي" }
}

object Rem {
    private fun pi(ctx: Context, code: Int, title: String, text: String): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, code,
            Intent(ctx, ReminderReceiver::class.java).putExtra("t", title).putExtra("x", text).putExtra("c", code),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    fun notify(ctx: Context, title: String?, text: String?, code: Int) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, Snd.channelId(ctx))
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try { nm.notify(code, n) } catch (_: SecurityException) {}
    }

    fun apply(ctx: Context, json: String) {
        val prefs = ctx.getSharedPreferences("rem", Context.MODE_PRIVATE)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        (prefs.getStringSet("ids", emptySet()) ?: emptySet()).forEach { am.cancel(pi(ctx, it.toInt(), "", "")) }
        val ids = HashSet<String>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val at = o.getLong("at")
                if (at <= System.currentTimeMillis()) continue
                val code = o.getInt("code")
                val p = pi(ctx, code, o.getString("title"), o.getString("text"))
                if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
                ids.add(code.toString())
            }
        } catch (_: Exception) {}
        prefs.edit().putStringSet("ids", ids).putString("json", json).apply()
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        Rem.notify(ctx, i.getStringExtra("t"), i.getStringExtra("x"), i.getIntExtra("c", 0))
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        Rem.apply(ctx, ctx.getSharedPreferences("rem", Context.MODE_PRIVATE).getString("json", "[]") ?: "[]")
    }
}
