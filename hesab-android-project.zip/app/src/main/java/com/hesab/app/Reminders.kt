package com.hesab.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONArray

object Rem {
    private fun pi(ctx: Context, code: Int, title: String, text: String): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, code,
            Intent(ctx, ReminderReceiver::class.java).putExtra("t", title).putExtra("x", text).putExtra("c", code),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    fun apply(ctx: Context, json: String) {
        val prefs = ctx.getSharedPreferences("rem", Context.MODE_PRIVATE)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        (prefs.getStringSet("ids", emptySet()) ?: emptySet()).forEach { am.cancel(pi(ctx, it.toInt(), "", "")) }
        val ids = HashSet<String>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val at = o.getLong("at")
                if (at <= System.currentTimeMillis()) continue
                val code = o.getInt("code")
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(ctx, code, o.getString("title"), o.getString("text")))
                ids.add(code.toString())
            }
        } catch (_: Exception) {}
        prefs.edit().putStringSet("ids", ids).putString("json", json).apply()
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("appts", "المواعيد", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, "appts")
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(i.getStringExtra("t"))
            .setContentText(i.getStringExtra("x"))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try { nm.notify(i.getIntExtra("c", 0), n) } catch (_: SecurityException) {}
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        Rem.apply(ctx, ctx.getSharedPreferences("rem", Context.MODE_PRIVATE).getString("json", "[]") ?: "[]")
    }
}
